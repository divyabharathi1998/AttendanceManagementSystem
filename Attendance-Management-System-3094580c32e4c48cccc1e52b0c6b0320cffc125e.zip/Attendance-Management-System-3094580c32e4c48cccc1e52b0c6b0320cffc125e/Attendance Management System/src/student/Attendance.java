package student;

public interface Attendance {
	public void CalculateAttendance();
	public void DisplayAttendance();

}




